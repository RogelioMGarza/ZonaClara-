import { useState, useCallback } from "react";

/* ─── DATA ─────────────────────────────────────────────────────────────── */
const DB = {
  "H3/100/40/20": {
    name: "Fracc. Las Misiones, Querétaro",
    type: "Habitacional densidad media",
    typeClass: "hab",
    specs: [
      { val: "60%", label: "COS — Ocupación del suelo", w: 60 },
      { val: "1.8", label: "CUS — Utilización del suelo", w: 60 },
      { val: "5 m", label: "Restricción frontal", w: 40 },
      { val: "20%", label: "Área verde mínima", w: 40 },
      { val: "2", label: "Cajones por vivienda", w: 50 },
      { val: "3 m", label: "Restricción lateral", w: 30 },
    ],
    permits: [
      "Licencia de construcción",
      "Dictamen de uso de suelo",
      "Factibilidad agua/drenaje",
      "Aviso de terminación de obra",
    ],
    compliance: [
      { name: "Restricción frontal", need: "5.0 m", has: "5.4 m", note: "Cumple holgadamente.", status: "green" },
      { name: "Área verde", need: "20%", has: "19%", note: "Puede argumentarse con vegetación en azotea o cajetes.", status: "yellow" },
      { name: "Cajones de estacionamiento", need: "2", has: "2", note: "Exactamente lo requerido.", status: "green" },
      { name: "COS — Ocupación del suelo", need: "60%", has: "58%", note: "Dentro del límite permitido.", status: "green" },
      { name: "Restricción lateral este", need: "3.0 m", has: "2.2 m", note: "No cumple. Se requiere retroceder la construcción.", status: "red" },
      { name: "Altura máxima", need: "9.0 m", has: "8.7 m", note: "Dentro de lo permitido.", status: "green" },
    ],
    ai: "El plano cumple la mayoría de los requisitos habitacionales. El punto crítico es la restricción lateral este (2.2 m vs 3.0 m requeridos) que debe corregirse antes de tramitar la licencia. El área verde al 19% es negociable si se propone vegetación en macetas de azotea con sustrato mínimo de 40 cm.",
  },
  "CS2/80/60/15": {
    name: "Centro comercial, Juriquilla",
    type: "Comercial y servicios nivel 2",
    typeClass: "com",
    specs: [
      { val: "80%", label: "COS", w: 80 },
      { val: "2.4", label: "CUS", w: 80 },
      { val: "0 m", label: "Restricción frontal", w: 5 },
      { val: "15%", label: "Área verde mínima", w: 30 },
      { val: "1 c/30m²", label: "Cajones", w: 60 },
      { val: "—", label: "Restricción lateral", w: 0 },
    ],
    permits: [
      "Licencia de construcción comercial",
      "Estudio de impacto urbano",
      "Permiso imagen urbana",
      "Dictamen protección civil",
      "Factibilidad de servicios",
    ],
    compliance: [
      { name: "COS — Ocupación del suelo", need: "80%", has: "76%", note: "Cumple, hay margen de 4% adicional.", status: "green" },
      { name: "Cajones de estacionamiento", need: "28", has: "22", note: "Déficit de 6 cajones. Puede resolverse con convenio de vialeta.", status: "yellow" },
      { name: "Área verde", need: "15%", has: "9%", note: "No cumple. Requiere jardines o cubierta verde en azotea.", status: "red" },
      { name: "Altura máxima", need: "18 m", has: "14 m", note: "Bien dentro del límite.", status: "green" },
      { name: "Accesibilidad (rampas)", need: "2", has: "2", note: "Cumple normativa de accesibilidad.", status: "green" },
    ],
    ai: "El proyecto comercial presenta dos observaciones: el déficit de cajones (22 vs 28) puede subsanarse con un convenio de uso compartido con predio colindante. El área verde (9% vs 15%) es el reto mayor — se recomienda diseño de azotea verde con sistema de riego para alcanzar el mínimo.",
  },
  "MX1/90/50/25": {
    name: "Col. Centro, San Juan del Río",
    type: "Uso mixto habitacional-comercial",
    typeClass: "mix",
    specs: [
      { val: "70%", label: "COS", w: 70 },
      { val: "2.1", label: "CUS", w: 70 },
      { val: "3 m", label: "Restricción frontal", w: 30 },
      { val: "25%", label: "Área verde mínima", w: 50 },
      { val: "1.5 c/viv", label: "Cajones", w: 50 },
      { val: "2 m", label: "Restricción lateral", w: 20 },
    ],
    permits: [
      "Licencia de construcción mixta",
      "Dictamen de uso de suelo",
      "Factibilidad de servicios",
      "Memoria descriptiva de usos",
    ],
    compliance: [
      { name: "Restricción frontal", need: "3.0 m", has: "3.1 m", note: "Cumple por 10 cm — verificar tolerancia.", status: "green" },
      { name: "Área verde", need: "25%", has: "24%", note: "A 1% del mínimo. Jardín interior con doble altura puede contar.", status: "yellow" },
      { name: "Cajones de estacionamiento", need: "12", has: "12", note: "Exactamente lo requerido.", status: "green" },
      { name: "COS", need: "70%", has: "68%", note: "Bien dentro del límite.", status: "green" },
      { name: "Restricción lateral", need: "2.0 m", has: "1.5 m", note: "No cumple. Requiere ajuste de planta.", status: "red" },
    ],
    ai: "El proyecto mixto está muy cerca de cumplimiento total. La restricción lateral de 1.5 m (vs 2.0 m) es la única corrección estructural requerida — implica retirar aproximadamente 50 cm en la fachada lateral. El área verde al 24% puede justificarse si el jardín interior se computa con la metodología de IMPLAN.",
  },
  "IN4/70/35/10": {
    name: "Parque industrial, El Marqués",
    type: "Industrial ligera nivel 4",
    typeClass: "ind",
    specs: [
      { val: "70%", label: "COS", w: 70 },
      { val: "1.4", label: "CUS", w: 47 },
      { val: "10 m", label: "Restricción frontal", w: 70 },
      { val: "10%", label: "Área verde mínima", w: 20 },
      { val: "1 c/100m²", label: "Cajones", w: 40 },
      { val: "5 m", label: "Restricción lateral", w: 40 },
    ],
    permits: [
      "Licencia industrial",
      "Manifestación de impacto ambiental",
      "Protección civil industrial",
      "Registro SEMARNAT",
      "Plan manejo residuos",
      "Aviso COFEPRIS",
    ],
    compliance: [
      { name: "Restricción frontal (acceso carga)", need: "10.0 m", has: "10.2 m", note: "Cumple. Suficiente para maniobra de camiones.", status: "green" },
      { name: "Cajones de estacionamiento", need: "18", has: "10", note: "Déficit de 8 cajones. No resolvible con convenio en zona industrial.", status: "red" },
      { name: "Área verde", need: "10%", has: "11%", note: "Cumple con margen.", status: "green" },
      { name: "Restricción lateral norte", need: "5.0 m", has: "4.5 m", note: "A 50 cm del mínimo — puede negociarse con servidumbre notariada.", status: "yellow" },
      { name: "Altura de nave", need: "12.0 m", has: "9.0 m", note: "No cumple altura mínima industrial. Requiere rediseño estructural.", status: "red" },
      { name: "Zona de maniobras internas", need: "200 m²", has: "210 m²", note: "Cumple holgadamente.", status: "green" },
    ],
    ai: "El proyecto industrial tiene dos incumplimientos importantes: el déficit de cajones (10 vs 18) y la altura de nave (9 m vs 12 m). Ambos requieren rediseño antes de presentar la licencia. La restricción lateral norte de 4.5 m puede argumentarse si el predio colindante acepta una servidumbre de paso firmada ante notario.",
  },
};

/* ─── STYLES ────────────────────────────────────────────────────────────── */
const css = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@400;500&family=Instrument+Sans:wght@400;500;600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --ink: #0E1117;
    --paper: #F5F2EC;
    --paper2: #EDE9E0;
    --paper3: #E2DDD3;
    --accent: #1B4FD8;
    --muted: #7A7570;
    --border: #C8C3B8;
    --g: #1A6B3C; --g-bg: #EBF5EF; --g-bd: #A3D4B5;
    --y: #7A5800; --y-bg: #FEF9E7; --y-bd: #F0C040;
    --r: #A8200D; --r-bg: #FCEEE9; --r-bd: #F5A090;
    --radius: 4px; --radius-lg: 8px;
  }

  body { font-family: 'Instrument Sans', sans-serif; background: var(--paper); color: var(--ink); font-size: 14px; line-height: 1.5; min-height: 100vh; }

  .nav { display: flex; align-items: center; justify-content: space-between; padding: 14px 32px; border-bottom: 1px solid var(--border); background: var(--paper); position: sticky; top: 0; z-index: 100; }
  .logo { font-family: 'DM Serif Display', serif; font-size: 19px; display: flex; align-items: center; gap: 8px; }
  .logo-dot { width: 7px; height: 7px; border-radius: 50%; background: #D4390A; display: inline-block; }
  .nav-tag { font-family: 'DM Mono', monospace; font-size: 10px; background: var(--accent); color: #fff; padding: 2px 7px; border-radius: 2px; letter-spacing: .05em; }

  .step-bar { display: flex; align-items: center; padding: 14px 32px; border-bottom: 1px solid var(--border); background: var(--paper2); gap: 0; }
  .step-item { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--muted); transition: color .2s; }
  .step-item.active { color: var(--ink); font-weight: 600; }
  .step-item.done { color: var(--g); }
  .step-num { width: 22px; height: 22px; border-radius: 50%; border: 1.5px solid var(--border); display: flex; align-items: center; justify-content: center; font-family: 'DM Mono', monospace; font-size: 10px; transition: all .2s; flex-shrink: 0; }
  .step-item.active .step-num { border-color: var(--accent); background: var(--accent); color: #fff; }
  .step-item.done .step-num { border-color: var(--g); background: var(--g); color: #fff; }
  .step-div { flex: 1; height: 1px; background: var(--border); margin: 0 12px; min-width: 20px; }

  .main { max-width: 860px; margin: 0 auto; padding: 36px 32px; }

  .panel { animation: fadein .25s ease; }
  @keyframes fadein { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }

  .section-label { font-family: 'DM Mono', monospace; font-size: 10px; letter-spacing: .12em; text-transform: uppercase; color: var(--muted); display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
  .section-label::before { content: ''; display: block; width: 20px; height: 1px; background: var(--muted); }

  h1.hero { font-family: 'DM Serif Display', serif; font-size: 30px; line-height: 1.15; letter-spacing: -.5px; margin-bottom: 10px; }
  h1.hero em { font-style: italic; color: var(--accent); }
  .hero-sub { font-size: 13px; color: var(--muted); max-width: 500px; line-height: 1.6; margin-bottom: 28px; }

  .input-row { display: flex; gap: 8px; max-width: 480px; }
  .code-input { flex: 1; font-family: 'DM Mono', monospace; font-size: 15px; padding: 11px 14px; border: 1.5px solid var(--border); border-radius: var(--radius); background: var(--paper); color: var(--ink); letter-spacing: .06em; outline: none; transition: border-color .15s; }
  .code-input:focus { border-color: var(--accent); }
  .code-input::placeholder { color: var(--muted); opacity: .5; }

  .btn { font-family: 'Instrument Sans', sans-serif; font-size: 13px; font-weight: 600; padding: 11px 20px; border: none; border-radius: var(--radius); cursor: pointer; transition: all .15s; letter-spacing: .01em; white-space: nowrap; }
  .btn-primary { background: var(--accent); color: #fff; }
  .btn-primary:hover { background: #1540B0; }
  .btn-primary:active { transform: scale(.98); }
  .btn-outline { background: var(--paper); color: var(--ink); border: 1.5px solid var(--border); }
  .btn-outline:hover { border-color: var(--ink); }
  .btn-ghost { background: transparent; color: var(--muted); border: 1.5px solid var(--border); font-size: 12px; padding: 8px 14px; }
  .btn-ghost:hover { color: var(--ink); border-color: var(--ink); }

  .samples { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 10px; align-items: center; }
  .samples-label { font-size: 11px; color: var(--muted); }
  .sample-btn { font-family: 'DM Mono', monospace; font-size: 11px; padding: 4px 10px; border: 1px solid var(--border); border-radius: var(--radius); background: var(--paper); cursor: pointer; color: var(--muted); transition: all .15s; }
  .sample-btn:hover { color: var(--accent); border-color: var(--accent); }

  .hint { font-size: 11px; color: var(--muted); margin-top: 6px; }
  .hint code { font-family: 'DM Mono', monospace; background: var(--paper3); padding: 1px 5px; border-radius: 2px; }

  .zone-summary { background: var(--paper2); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 14px 20px; margin-bottom: 24px; display: flex; align-items: center; gap: 16px; }
  .zone-code-badge { font-family: 'DM Mono', monospace; font-size: 13px; font-weight: 500; background: var(--paper); border: 1px solid var(--border); padding: 6px 12px; border-radius: var(--radius); color: var(--accent); flex-shrink: 0; }
  .zone-name { font-size: 13px; font-weight: 600; margin-bottom: 3px; }
  .type-tag { display: inline-block; font-family: 'DM Mono', monospace; font-size: 10px; padding: 2px 8px; border-radius: 2px; text-transform: uppercase; }
  .type-tag.hab { background: #E8F0FE; color: #1B4FD8; border: 1px solid #B3C8F5; }
  .type-tag.com { background: #FEF3E8; color: #9A4A00; border: 1px solid #F5D0A0; }
  .type-tag.mix { background: #EBF5EF; color: #1A6B3C; border: 1px solid #A3D4B5; }
  .type-tag.ind { background: #F5ECFE; color: #6B1A9E; border: 1px solid #D4A3F5; }

  .choice-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; max-width: 640px; margin-top: 24px; }
  .choice-card { border: 1.5px solid var(--border); border-radius: var(--radius-lg); padding: 28px 24px; cursor: pointer; transition: all .2s; background: var(--paper); }
  .choice-card:hover { border-color: var(--accent); background: #EEF2FC; transform: translateY(-2px); }
  .choice-icon { font-size: 28px; margin-bottom: 12px; }
  .choice-title { font-family: 'DM Serif Display', serif; font-size: 18px; margin-bottom: 6px; }
  .choice-sub { font-size: 12px; color: var(--muted); line-height: 1.5; }

  .back-btn { font-family: 'DM Mono', monospace; font-size: 11px; color: var(--muted); background: none; border: none; cursor: pointer; padding: 0; transition: color .15s; display: flex; align-items: center; gap: 4px; margin-bottom: 20px; }
  .back-btn:hover { color: var(--ink); }

  .specs-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 24px; }
  .spec-card { background: var(--paper); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px 16px; }
  .spec-val { font-family: 'DM Serif Display', serif; font-size: 24px; letter-spacing: -.3px; line-height: 1; margin-bottom: 4px; }
  .spec-lbl { font-size: 11px; color: var(--muted); line-height: 1.4; }
  .spec-bar { height: 3px; border-radius: 2px; background: var(--paper3); margin-top: 8px; overflow: hidden; }
  .spec-fill { height: 100%; border-radius: 2px; background: var(--accent); transition: width .6s ease; }

  .permits-block { border: 1px solid var(--border); border-radius: var(--radius-lg); overflow: hidden; background: var(--paper); }
  .permits-header { padding: 11px 16px; border-bottom: 1px solid var(--border); font-size: 12px; font-weight: 600; display: flex; align-items: center; justify-content: space-between; }
  .permit-count { font-family: 'DM Mono', monospace; font-size: 10px; background: var(--accent); color: #fff; padding: 2px 7px; border-radius: 2px; }
  .permit-row { padding: 10px 16px; border-bottom: 1px solid var(--paper3); display: flex; align-items: center; gap: 10px; font-size: 12px; }
  .permit-row:last-child { border-bottom: none; }
  .permit-dot { width: 5px; height: 5px; border-radius: 50%; background: #D4390A; flex-shrink: 0; }

  .drop-zone { border: 1.5px dashed var(--border); border-radius: var(--radius-lg); background: var(--paper2); padding: 40px 28px; display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; cursor: pointer; transition: all .2s; margin-bottom: 16px; max-width: 520px; }
  .drop-zone:hover, .drop-zone.over { border-color: var(--accent); background: #EEF2FC; }
  .drop-zone.loaded { border-color: var(--g); background: var(--g-bg); border-style: solid; }
  .drop-icon { width: 44px; height: 44px; border: 1.5px solid var(--border); border-radius: var(--radius); background: var(--paper); display: flex; align-items: center; justify-content: center; font-size: 20px; }
  .drop-zone h3 { font-size: 14px; font-weight: 600; }
  .drop-zone p { font-size: 12px; color: var(--muted); }
  .file-tags { display: flex; gap: 6px; }
  .file-tag { font-family: 'DM Mono', monospace; font-size: 10px; padding: 2px 6px; border: 1px solid var(--border); border-radius: 2px; color: var(--muted); }

  .summary-bar { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 24px; }
  .sum-card { border-radius: var(--radius); padding: 14px 16px; text-align: center; border: 1.5px solid; }
  .sum-card.green { border-color: var(--g-bd); background: var(--g-bg); }
  .sum-card.yellow { border-color: var(--y-bd); background: var(--y-bg); }
  .sum-card.red { border-color: var(--r-bd); background: var(--r-bg); }
  .sum-n { font-family: 'DM Serif Display', serif; font-size: 28px; line-height: 1; margin-bottom: 2px; }
  .sum-n.green { color: var(--g); }
  .sum-n.yellow { color: var(--y); }
  .sum-n.red { color: var(--r); }
  .sum-lbl { font-size: 11px; color: var(--muted); }

  .compliance-list { display: flex; flex-direction: column; gap: 8px; }
  .comp-row { border-radius: var(--radius-lg); border: 1.5px solid; padding: 14px 18px; display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 14px; transition: transform .15s; }
  .comp-row:hover { transform: translateX(2px); }
  .comp-row.green { border-color: var(--g-bd); background: var(--g-bg); }
  .comp-row.yellow { border-color: var(--y-bd); background: var(--y-bg); }
  .comp-row.red { border-color: var(--r-bd); background: var(--r-bg); }
  .comp-icon { font-size: 16px; width: 24px; text-align: center; }
  .comp-name { font-size: 13px; font-weight: 600; margin-bottom: 2px; }
  .comp-note { font-size: 12px; color: var(--muted); margin-bottom: 4px; }
  .comp-tag { font-family: 'DM Mono', monospace; font-size: 9px; padding: 2px 6px; border-radius: 2px; display: inline-block; }
  .comp-tag.green { background: var(--g-bg); color: var(--g); border: 1px solid var(--g-bd); }
  .comp-tag.yellow { background: var(--y-bg); color: var(--y); border: 1px solid var(--y-bd); }
  .comp-tag.red { background: var(--r-bg); color: var(--r); border: 1px solid var(--r-bd); }
  .comp-values { text-align: right; }
  .comp-has { font-family: 'DM Serif Display', serif; font-size: 18px; line-height: 1; }
  .comp-has.green { color: var(--g); }
  .comp-has.yellow { color: var(--y); }
  .comp-has.red { color: var(--r); }
  .comp-need { font-size: 11px; color: var(--muted); margin-top: 1px; }

  .ai-card { border: 1.5px solid var(--accent); border-radius: var(--radius-lg); padding: 16px 18px; background: linear-gradient(135deg, #EEF2FC, var(--paper2)); margin-top: 20px; }
  .ai-head { font-size: 11px; font-weight: 600; color: var(--accent); display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
  .ai-pulse { width: 7px; height: 7px; border-radius: 50%; background: var(--accent); animation: pulse 2s ease-in-out infinite; }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: .4; } }
  .ai-text { font-family: 'DM Serif Display', serif; font-style: italic; font-size: 13px; line-height: 1.6; }

  .action-row { display: flex; gap: 10px; margin-top: 28px; flex-wrap: wrap; }

  .footer-note { font-family: 'DM Mono', monospace; font-size: 10px; color: var(--muted); border-top: 1px solid var(--border); padding: 16px 32px; text-align: center; letter-spacing: .04em; margin-top: 40px; }
`;

/* ─── STEP BAR ──────────────────────────────────────────────────────────── */
const STEPS = ["Código", "Opción", "Resultado"];
const stepMap = { 1: 0, 2: 1, 3: 1, 4: 1, 5: 2 };

function StepBar({ step }) {
  const active = stepMap[step];
  return (
    <div className="step-bar">
      {STEPS.map((s, i) => (
        <>
          <div key={s} className={`step-item ${i === active ? "active" : i < active ? "done" : ""}`}>
            <div className="step-num">{i < active ? "✓" : i + 1}</div>
            {s}
          </div>
          {i < STEPS.length - 1 && <div key={`div-${i}`} className="step-div" />}
        </>
      ))}
    </div>
  );
}

/* ─── ZONE SUMMARY ──────────────────────────────────────────────────────── */
function ZoneSummary({ code }) {
  const d = DB[code];
  if (!d) return null;
  return (
    <div className="zone-summary">
      <span className="zone-code-badge">{code}</span>
      <div>
        <div className="zone-name">{d.name}</div>
        <span className={`type-tag ${d.typeClass}`}>{d.type}</span>
      </div>
    </div>
  );
}

/* ─── STEP 1: Code Entry ────────────────────────────────────────────────── */
function Step1({ onNext }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState(false);

  const submit = () => {
    if (DB[code.trim()]) { setError(false); onNext(code.trim()); }
    else setError(true);
  };

  return (
    <div className="panel">
      <div className="section-label">Inicio</div>
      <h1 className="hero">Ingresa la <em>clave</em><br />de tu predio.</h1>
      <p className="hero-sub">Consulta la zonificación, restricciones y trámites de cualquier predio en segundos.</p>
      <div className="input-row">
        <input
          className="code-input"
          value={code}
          onChange={e => { setCode(e.target.value); setError(false); }}
          onKeyDown={e => e.key === "Enter" && submit()}
          placeholder="Ej. H3/100/40/20"
          style={error ? { borderColor: "var(--r)" } : {}}
        />
        <button className="btn btn-primary" onClick={submit}>Buscar →</button>
      </div>
      {error && <div className="hint" style={{ color: "var(--r)", marginTop: 6 }}>Clave no encontrada. Prueba uno de los ejemplos.</div>}
      {!error && <div className="hint">Clave del <code>plan parcial</code> o <code>DENUE</code> de tu municipio</div>}
      <div className="samples">
        <span className="samples-label">Ejemplos:</span>
        {Object.keys(DB).map(k => (
          <button key={k} className="sample-btn" onClick={() => { setCode(k); setError(false); }}>{k}</button>
        ))}
      </div>
    </div>
  );
}

/* ─── STEP 2: Choice ────────────────────────────────────────────────────── */
function Step2({ code, onBack, onInfo, onUpload }) {
  return (
    <div className="panel">
      <button className="back-btn" onClick={onBack}>← Cambiar clave</button>
      <ZoneSummary code={code} />
      <div className="section-label">¿Qué deseas hacer?</div>
      <h1 className="hero" style={{ fontSize: 24, marginBottom: 8 }}>Elige cómo continuar</h1>
      <p className="hero-sub" style={{ marginBottom: 0 }}>Consulta los requisitos del predio, o sube tu plano para analizarlo automáticamente.</p>
      <div className="choice-grid">
        <div className="choice-card" onClick={onInfo}>
          <div className="choice-icon">📋</div>
          <div className="choice-title">Ver requisitos</div>
          <div className="choice-sub">Consulta restricciones de construcción, coeficientes y trámites necesarios para esta zona.</div>
        </div>
        <div className="choice-card" onClick={onUpload}>
          <div className="choice-icon">📐</div>
          <div className="choice-title">Analizar plano</div>
          <div className="choice-sub">Sube tu plano arquitectónico y la IA verificará qué requisitos cumple, cuáles están en riesgo y cuáles faltan.</div>
        </div>
      </div>
    </div>
  );
}

/* ─── STEP 3: Info View ─────────────────────────────────────────────────── */
function Step3({ code, onBack, onUpload }) {
  const d = DB[code];
  return (
    <div className="panel">
      <button className="back-btn" onClick={onBack}>← Regresar</button>
      <ZoneSummary code={code} />
      <div className="section-label">Restricciones de construcción</div>
      <div className="specs-grid">
        {d.specs.map((s, i) => (
          <div key={i} className="spec-card">
            <div className="spec-val">{s.val}</div>
            <div className="spec-lbl">{s.label}</div>
            <div className="spec-bar"><div className="spec-fill" style={{ width: `${s.w}%` }} /></div>
          </div>
        ))}
      </div>
      <div className="section-label">Trámites y permisos requeridos</div>
      <div className="permits-block">
        <div className="permits-header">
          Trámites requeridos
          <span className="permit-count">{d.permits.length} trámites</span>
        </div>
        {d.permits.map((p, i) => (
          <div key={i} className="permit-row">
            <div className="permit-dot" />
            {p}
          </div>
        ))}
      </div>
      <div className="action-row">
        <button className="btn btn-primary" onClick={onUpload}>Analizar mi plano →</button>
        <button className="btn btn-outline" onClick={onBack}>Regresar</button>
      </div>
    </div>
  );
}

/* ─── STEP 4: Upload ────────────────────────────────────────────────────── */
function Step4({ code, onBack, onAnalyze }) {
  const [loaded, setLoaded] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setLoaded(true);
  }, []);

  const analyze = () => {
    setAnalyzing(true);
    setTimeout(() => onAnalyze(), 900);
  };

  return (
    <div className="panel">
      <button className="back-btn" onClick={onBack}>← Regresar</button>
      <ZoneSummary code={code} />
      <div className="section-label">Análisis de plano</div>
      <h1 className="hero" style={{ fontSize: 24, marginBottom: 8 }}>Sube tu <em>plano</em></h1>
      <p className="hero-sub">La IA verificará cada requisito y te dirá qué cumples, qué casi cumples y qué necesitas corregir.</p>
      <div
        className={`drop-zone${loaded ? " loaded" : ""}`}
        onClick={() => setLoaded(true)}
        onDrop={handleDrop}
        onDragOver={e => e.preventDefault()}
      >
        <div className="drop-icon">{loaded ? "✅" : "📂"}</div>
        <h3>{loaded ? "plano_proyecto.pdf cargado" : "Arrastra tu plano aquí"}</h3>
        <p>{loaded ? "Archivo listo para analizar" : "o haz clic para seleccionar un archivo"}</p>
        {!loaded && (
          <div className="file-tags">
            {["PDF", "PNG", "JPG", "DWG"].map(t => <span key={t} className="file-tag">{t}</span>)}
          </div>
        )}
      </div>
      {loaded && (
        <button className="btn btn-primary" onClick={analyze} disabled={analyzing} style={{ width: "100%", maxWidth: 520 }}>
          {analyzing ? "Analizando…" : "Analizar plano con IA →"}
        </button>
      )}
      <button className="btn btn-ghost" onClick={analyze} disabled={analyzing} style={{ marginTop: 8, display: "block" }}>
        Continuar con demo sin archivo →
      </button>
    </div>
  );
}

/* ─── STEP 5: Compliance Results ────────────────────────────────────────── */
const STATUS_ICON = { green: "✅", yellow: "⚠️", red: "❌" };
const STATUS_LABEL = { green: "CUMPLE", yellow: "EN RIESGO", red: "NO CUMPLE" };

function Step5({ code, onBack, onReset, onInfo }) {
  const d = DB[code];
  const counts = d.compliance.reduce((acc, c) => { acc[c.status]++; return acc; }, { green: 0, yellow: 0, red: 0 });

  return (
    <div className="panel">
      <button className="back-btn" onClick={onBack}>← Subir otro plano</button>
      <ZoneSummary code={code} />
      <div className="section-label">Resultado del análisis</div>

      <div className="summary-bar">
        {[["green", "Cumple ✓"], ["yellow", "En riesgo ≈"], ["red", "No cumple ✗"]].map(([s, label]) => (
          <div key={s} className={`sum-card ${s}`}>
            <div className={`sum-n ${s}`}>{counts[s]}</div>
            <div className="sum-lbl">{label}</div>
          </div>
        ))}
      </div>

      <div className="compliance-list">
        {d.compliance.map((item, i) => (
          <div key={i} className={`comp-row ${item.status}`}>
            <div className="comp-icon">{STATUS_ICON[item.status]}</div>
            <div>
              <div className="comp-name">{item.name}</div>
              <div className="comp-note">{item.note}</div>
              <span className={`comp-tag ${item.status}`}>{STATUS_LABEL[item.status]}</span>
            </div>
            <div className="comp-values">
              <div className={`comp-has ${item.status}`}>{item.has}</div>
              <div className="comp-need">req. {item.need}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="ai-card">
        <div className="ai-head">
          <div className="ai-pulse" />
          Resumen de IA
        </div>
        <p className="ai-text">"{d.ai}"</p>
      </div>

      <div className="action-row">
        <button className="btn btn-primary" onClick={onReset}>Nueva consulta</button>
        <button className="btn btn-outline" onClick={onInfo}>Ver todos los requisitos</button>
      </div>
    </div>
  );
}

/* ─── ROOT APP ──────────────────────────────────────────────────────────── */
export default function App() {
  const [step, setStep] = useState(1);
  const [code, setCode] = useState("");

  const go = (n) => { setStep(n); window.scrollTo(0, 0); };

  return (
    <>
      <style>{css}</style>
      <nav className="nav">
        <div className="logo">
          <span className="logo-dot" />
          ZonaUrb
          <span className="nav-tag">PROTOTIPO</span>
        </div>
      </nav>

      <StepBar step={step} />

      <div className="main">
        {step === 1 && <Step1 onNext={c => { setCode(c); go(2); }} />}
        {step === 2 && <Step2 code={code} onBack={() => go(1)} onInfo={() => go(3)} onUpload={() => go(4)} />}
        {step === 3 && <Step3 code={code} onBack={() => go(2)} onUpload={() => go(4)} />}
        {step === 4 && <Step4 code={code} onBack={() => go(2)} onAnalyze={() => go(5)} />}
        {step === 5 && <Step5 code={code} onBack={() => go(4)} onReset={() => { setCode(""); go(1); }} onInfo={() => go(3)} />}
      </div>

      <div className="footer-note">DATOS BASADOS EN PLANES PARCIALES MUNICIPALES · VERSIÓN PROTOTIPO</div>
    </>
  );
}
